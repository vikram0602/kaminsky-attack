import binascii
import sys
file=open("payload2","ab")
hs = "587601000001000000000000037777770e646e737068697368696e676c616203636f6d0000010001"
hx = binascii.a2b_hex(hs)
file.write(hx)
file.close()
